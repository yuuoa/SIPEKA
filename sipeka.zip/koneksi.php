<?php 

$koneksi = mysqli_connect("localhost", "root", "" ,"sipeka");

?>