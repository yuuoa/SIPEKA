    <!doctype html>
    <html class="no-js" lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Login User | Sistem Informasi Arsip Digital</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" type="image/x-icon" href="../gambar/sistem/favicon.ico">
    <link href="https://fonts.googleapis.com/css?family=Play:400,700" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/style.css">
    <link rel="stylesheet" href="assets/css/responsive.css">
    <script src="assets/js/vendor/modernizr-2.8.3.min.js"></script>
</head>

    <body class="bg-wt" >
            <div class="error-pagewrap">
        <div class="error-page-int">
            <div class="text-center m-b-md custom-login" style="width: 100%;">
			
            <img class="main-logo"src="assets/img/logo/sipeka.png" style="padding-bottom: 50px; " alt=""></a>

            </div>
			
			
			
            <div class="content-error">
             
                <div class="hpanel">
				<br>
				<br>
                    <div class="panel-body">
                        <center>
                            <h4>MENU LOGIN</h4>    
                        </center>
<center>
				
			<!--	<a href="user_login.php" ><i ></i> Login User</a> -->
				<a href="login.php" ><i ></i>Pelaporan RKL/RPL</a>
				<!-- <a href="www.google.com" ><i ></i>Pelaporan Baku Mutu</a> -->
                <br>
                <br>
					
                    </center>
                </div>
           </div>

           <br>
           <br>
           <br>
           <br>
           <br>
           <br>

            <center>
           <div class="text-center m-b-md custom-login" style="width: 40%;">
            <img class="main-logo"src="assets/img/logo/logokim.png" style="padding-top: 30px;" alt=""></a>
            </div>            
			</center>
</div>
		

   



        <script src="assets/js/vendor/jquery-1.12.4.min.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
    </body>

    </html>