(function ($) {
 "use strict";

		$('a.media').media({width:700, height:650});
		 
 
})(jQuery); 